 document.getElementById("LoginForm").addEventListener('submit',function(event) {
        event.preventDefault();
        
        var Username = document.getElementById('Username').value;
        var password = document.getElementById('password').value;
        var errorMessage = document.getElementById('error-message');
        
        if (Username === '' || password === ''){
            errorMessage.textContent = 'berotak senku jangan dikosongin dong';
        } else if (Username !== 'Fauzan Tri' || password !=='12315') {
            errorMessage.textContent = 'maaf password atau username salah';
        } else {
            errorMessage.textContent = ''
            alert('login berhasil');
        }
        
      } );
      